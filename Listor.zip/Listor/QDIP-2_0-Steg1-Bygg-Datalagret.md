# QDIP 2.0 — Steg 1: Bygg datalagret (tunn skiva)

**Vad vi bygger:** 5 SharePoint-listor som bevisar hela loopen med ett enda mått (NRFT).
**Tid:** ~45 minuter
**Filosofi:** Less is more. Rik dimension + rik config (matas en gång), **mager faktatabell** (skrivs dagligen).

---

## Arkitekturen i en bild

```
KONFIG (matas en gång)              FAKTA (skrivs dagligen)         UTVÄRDERING
─────────────────────               ───────────────────────         ───────────
QDIP_FiscalCalendar   ──┐
  (vilka dagar, mål-      ├──►  QDIP_MetricResults  ──────────►  Power BI
   datum, fiskalmånad)    │       (Value = 2)                     jämför Value
                          │              │                        mot målet
QDIP_MetricDefinitions ──┘              │                        → GRÖN/RÖD
  (NRFT ≤ 0 = grönt)                    ▼
                              QDIP_ResultCauses
QDIP_CauseDefinitions ──────►   (CauseID + antal)
  (11 NRFT-orsaker)
```

**Kärnprincip:** SharePoint lagrar **råvärden**. Power BI **utvärderar**. Aldrig två motorer som kan glida isär.

---

## Varför designen ser ut så här (så du förstår, inte bara följer)

| Val | Varför |
|---|---|
| **Ingen `EvaluatedStatus` i faktatabellen** | Du har redan 80 DAX-mått som utvärderar. Lagrar vi status också får vi två sanningar som kan glida isär. Power BI räknar. |
| **`DefinitionKey` på varje resultatrad** | När EHS-checklistan går 28→36 poäng vet vi vilken regel som gällde den dagen. Historiken förblir korrekt. |
| **Orsaker som egen lista + bridge** | Lägg till en orsak = en ny rad. Aldrig mer schemaändring. Gamla modellen hade 20 wide-kolumner i Quality. |
| **`CauseCount` i bridge** (min korrigering) | Din ursprungsdesign hade bara "vilken orsak", inte "hur många". Gamla modellen räknade antal (Other=3). Det får inte tappas. |
| **`RecordState` istället för radering** | Aldrig hård-radera. Voided rader filtreras bort men finns kvar för spårbarhet. |
| **`Title` = sammansatt nyckel** | SharePoint kräver Title. Vi gör den meningsfull: `Q_NRFT\|2026-05-21` = unik och läsbar. |

---

## Lista 1 — `QDIP_FiscalCalendar`

**Fil:** din egen `QDIP_FiscalCalendar_2024-2036_v1_1.xlsx` (redan verifierad ✓)

Jag kontrollerade den: fiskala June 2026 = veckorna 22–26, start lördag 2026-05-23. QDIP:s due-date-logik (Mån–Tor → nästa dag, Fre–Sön → måndag) är inbyggd. Den är korrekt — vi använder den som den är.

### Skapa
1. SharePoint-siten → **New → List → From Excel**
2. Ladda upp filen, välj tabellen
3. Namn: **`QDIP_FiscalCalendar`**

### Kolumntyper att verifiera i förhandsvisningen
| Kolumn | Typ |
|---|---|
| RefDate | **Date and time** (Date only) |
| FiscalYear, FiscalMonthNum, FiscalWeekNum, DateKey | **Number** (0 decimaler) |
| FiscalMonthName, FiscalYearMonth, DayName m.fl. | Single line of text |
| QDIPLeadingExpected, CrossFiscalMonthReview m.fl. | **Yes/No** |
| QDIPLaggingDueDate, FiscalWeekStartDate m.fl. | **Date and time** |

### Efter import
**Settings → Indexed columns → Create new index → RefDate**
(Listan har >5000 rader; index krävs för SharePoint-UI:t.)

---

## Lista 2 — `QDIP_MetricDefinitions`

**Fil:** `QDIP_MetricDefinitions.xlsx` (bifogad — 21 kolumner, 1 seed-rad för NRFT)

Detta är **KPI-kontraktet**. Här bor målen. Ändra ett mål = ny version här, inte kodändring.

### Skapa
**New → List → From Excel** → namn: **`QDIP_MetricDefinitions`**

### Kolumntyper
| Kolumn | Typ | Kommentar |
|---|---|---|
| Title | Text | = DefinitionKey, t.ex. `Q_NRFT\|1.0` |
| MetricID | Text | Logiskt id |
| DefinitionVersion | Text | `1.0` |
| MetricName | Text | Visningsnamn |
| **Area** | **Choice** | EHS / Quality / Delivery |
| **MetricType** | **Choice** | Leading / Lagging |
| **ValueType** | **Choice** | Count / Score / Percentage / Ratio |
| Unit | Text | |
| DefinitionText | **Multiline text** | Dokumentation av måttet |
| **DailyTargetDirection** | **Choice** | AtMost / AtLeast / Between / Equals |
| DailyTargetMin | **Number** | |
| DailyTargetMax | **Number** | |
| DailyTargetText | Text | Visningstext, t.ex. "Day = 0" |
| **MonthlyAggregation** | **Choice** | Sum / Average / Ratio / Max / Min |
| MonthlyTargetText | Text | |
| **ReportingPattern** | **Choice** | LaggingPreviousDayMondayBacklog / LeadingSameDay / WeekdaysOnly |
| **SourceMode** | **Choice** | Manual / Automatic / Hybrid |
| **RequiresCauseWhenRed** | **Yes/No** | Tvingar orsak när dagen är röd |
| EffectiveFrom | **Date** | Versionsfönster start |
| IsActive | **Yes/No** | |
| SortOrder | **Number** | |

### Seed-raden förklarad (NRFT)
```
Title:                  Q_NRFT|1.0
DailyTargetDirection:   AtMost        ← "högst"
DailyTargetMax:         0             ← 0 fel = grönt
RequiresCauseWhenRed:   TRUE          ← orsak obligatorisk vid röd
ReportingPattern:       LaggingPreviousDayMondayBacklog
```
**Läs så här:** "NRFT ska vara högst 0 per dag. Blir den röd måste orsak anges."

---

## Lista 3 — `QDIP_CauseDefinitions`

**Fil:** `QDIP_CauseDefinitions.xlsx` (bifogad — 11 kolumner, **11 NRFT-orsaker seedade**)

### Skapa
**New → List → From Excel** → namn: **`QDIP_CauseDefinitions`**

### Kolumntyper
| Kolumn | Typ | Kommentar |
|---|---|---|
| Title | Text | = CauseID, t.ex. `NRFT_OTHER` |
| CauseName | Text | Visningsnamn i appen |
| **CauseCategory** | **Choice** | Documentation / Process / Other |
| **Area** | **Choice** | EHS / Quality / Delivery |
| MetricID | Text | Vilket mått orsaken hör till |
| Description | **Multiline text** | |
| **RequiresNote** | **Yes/No** | "Other" kräver fritext |
| EffectiveFrom | **Date** | |
| IsActive | **Yes/No** | |
| SortOrder | **Number** | Ordning i appen |
| LegacyColumn | Text | **Mappning till gamla wide-kolumnen (för migrering)** |

### De 11 NRFT-orsakerna
Documentation: Wrong info on checklist, Missing info on checklist, Missing signature on worksheet, Wrong revision for worksheet, Missing PDR on checklist, Missing PDR in worksheet, Missing/wrong OBR on checklist
Process: Carrier move on NC lot, Lot moved to NC flow but not on NC, Checklist not executed
Other: Other *(RequiresNote = TRUE)*

**`LegacyColumn` är nyckeln till migrering:** när vi flyttar dina 57 gamla Quality-rader vet vi exakt vilken gammal kolumn som blir vilken ny orsaksrad.

---

## Lista 4 — `QDIP_MetricResults` ⭐ faktatabellen

**Fil:** `QDIP_MetricResults.xlsx` (bifogad — **bara 11 kolumner**, 1 exempelrad)

Detta är den enda listan som skrivs varje dag. Därför är den avsiktligt mager — varje extra fält är friktion i inmatningen.

### Skapa
**New → List → From Excel** → namn: **`QDIP_MetricResults`**

### Kolumntyper
| Kolumn | Typ | Kommentar |
|---|---|---|
| Title | Text | = ResultKey: `Q_NRFT\|2026-05-21` — **unik** |
| **ReportingDate** | **Date** | Relationsnyckel mot kalendern |
| DateKey | **Number** | 20260521 — snabb heltalsnyckel |
| MetricID | Text | |
| DefinitionKey | Text | **Vilken målversion som gällde** |
| **Value** | **Number** | Råvärdet. Power BI utvärderar. |
| **ReportState** | **Choice** | NotExpected / Pending / Reported / SourceError |
| Notes | **Multiline text** | |
| EnteredByName | Text | Lätt audit |
| EnteredAt | **Date and time** | Lätt audit |
| **RecordState** | **Choice** | Active / Voided |

### Efter import — kritiskt
1. **Radera exempelraden** (den är markerad "EXEMPELRAD - radera efter import")
2. **Settings → Columns → Title → Enforce unique values = Yes**
   Detta gör det **omöjligt** att skapa två rader för samma mått+dag. En hel klass av buggar försvinner.
3. **Settings → Indexed columns → ReportingDate**

### ReportState förklarad (löser ett verkligt problem)
| Värde | Betyder | Färg i Power BI |
|---|---|---|
| `NotExpected` | Ingen rapport förväntas (helg) | Grå/tom |
| `Pending` | Förväntas men inte inmatad än | Amber |
| `Reported` | Inmatad — utvärdera värdet | Grön/Röd |
| `SourceError` | Automatisk källa fallerade | Mörkblå |

Gamla modellen kunde inte skilja "ingen rapport förväntad" från "rapport saknas". Nu kan den.

---

## Lista 5 — `QDIP_ResultCauses`

**Fil:** `QDIP_ResultCauses.xlsx` (bifogad — 6 kolumner, 1 exempelrad)

### Skapa
**New → List → From Excel** → namn: **`QDIP_ResultCauses`**

### Kolumntyper
| Kolumn | Typ | Kommentar |
|---|---|---|
| Title | Text | `Q_NRFT\|2026-05-21\|NRFT_OTHER` — **unik** |
| **ResultKey** | Text | Kopplar till MetricResults.Title |
| **CauseID** | Text | Kopplar till CauseDefinitions.Title |
| **CauseCount** | **Number** | **Antal (min korrigering — bevarar gamla modellens data)** |
| IsPrimary | **Yes/No** | Primär orsak |
| CauseNote | **Multiline text** | Fritext (obligatorisk för "Other") |

### Efter import
1. **Radera exempelraden**
2. **Title → Enforce unique values = Yes** (en orsak per resultat, inga dubbletter)
3. **Indexed columns → ResultKey**

---

## Verifiering — gör detta innan vi går vidare

- [ ] Alla 5 listor skapade med rätt namn
- [ ] `QDIP_FiscalCalendar`: sök på 2026-05-23 → ska visa FiscalMonthName=June, FiscalWeekNum=22
- [ ] `QDIP_MetricDefinitions`: 1 rad (`Q_NRFT|1.0`), DailyTargetMax = 0
- [ ] `QDIP_CauseDefinitions`: 11 rader, alla med MetricID = Q_NRFT
- [ ] `QDIP_MetricResults`: **0 rader** (exempelrad raderad), Title = unik
- [ ] `QDIP_ResultCauses`: **0 rader** (exempelrad raderad), Title = unik
- [ ] Choice-kolumner har rätt värden (inte text-kolumner)
- [ ] Index skapade på RefDate, ReportingDate, ResultKey

---

## Manuellt sluttest (bevisar att modellen fungerar)

Skapa **en rad manuellt** i `QDIP_MetricResults` via SharePoint-UI:t:

```
Title:          Q_NRFT|2026-07-21
ReportingDate:  2026-07-21
DateKey:        20260721
MetricID:       Q_NRFT
DefinitionKey:  Q_NRFT|1.0
Value:          2
ReportState:    Reported
EnteredByName:  <ditt namn>
EnteredAt:      <nu>
RecordState:    Active
```

Sedan en rad i `QDIP_ResultCauses`:
```
Title:       Q_NRFT|2026-07-21|NRFT_WRONG_INFO_CHECKLIST
ResultKey:   Q_NRFT|2026-07-21
CauseID:     NRFT_WRONG_INFO_CHECKLIST
CauseCount:  2
IsPrimary:   Yes
```

**Om båda raderna sparas utan fel → datalagret fungerar.** Det är vår testdata för Power BI i nästa steg.

---

## Vad som händer sedan

**Steg 2 — Power BI:** Ansluter de 5 listorna, bygger star schema, skriver DAX som utvärderar NRFT mot `DailyTargetMax` → grön/röd. Bevisar att utvärderingsmotorn fungerar mot den nya modellen.

**Steg 3 — Power App:** En skärm som skriver resultat + orsaker. Bevisar att den normaliserade skrivningen fungerar (den största tekniska risken).

**Steg 4 — Skala:** När loopen är bevisad lägger vi till EHS, LFI, Delivery — bara nya rader i MetricDefinitions och CauseDefinitions. **Ingen ny kod, ingen ny lista.** Det är hela poängen med designen.

---

## Om något krånglar

**"From Excel" hittar inte tabellen** → filen måste ha en formaterad Excel-tabell. Mina filer har det. Öppna, klicka i datan, kolla att Table Design-fliken visas.

**Datum blir text** → i förhandsvisningen, klicka kolumnrubriken och byt typ till "Date and time" innan Create.

**Choice-kolumner blir text** → SharePoint gissar Text. Ändra efter import: Settings → Columns → klicka kolumnen → Change type to Choice → fyll i värdena från tabellerna ovan.

**Kan inte sätta unique på Title** → kolumnen måste vara indexerad först. Settings → Indexed columns → Title, sedan unique.

---

När de 5 listorna står och sluttestet ovan gick igenom — säg **"klart"**, så bygger jag Power BI-lagret (M-kod + DAX) i nästa steg. 💪
